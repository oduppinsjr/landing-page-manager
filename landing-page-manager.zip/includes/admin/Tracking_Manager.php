<?php
namespace LPManager\admin;

class Tracking_Manager {

    public static function init() {
        add_action('template_redirect', [__CLASS__, 'increment_page_view']);
        add_action('wp_enqueue_scripts', [__CLASS__, 'enqueue_tracking_scripts']);
        add_action('wp_ajax_lpmanager_record_conversion', [__CLASS__, 'record_conversion']);
        add_action('wp_ajax_nopriv_lpmanager_record_conversion', [__CLASS__, 'record_conversion']);
		
		// Add submenu only after Carbon Fields is loaded and in admin
        add_action('admin_menu', [__CLASS__, 'maybe_add_conversions_submenu']);
    }

    public static function increment_page_view() {
        if (is_singular('landing_page')) {
            $post_id = get_the_ID();
            $views = (int) get_post_meta($post_id, '_lpmanager_page_views', true);
            update_post_meta($post_id, '_lpmanager_page_views', $views + 1);
        }
    }

    public static function enqueue_tracking_scripts() {
        if (is_singular('landing_page')) {
            $enable = carbon_get_theme_option('lpmanager_enable_conversion_tracking');
            if ($enable) {
                wp_enqueue_script(
                    'lpmanager-tracking',
                    LP_MANAGER_PLUGIN_URL . 'assets/js/tracking.js',
                    ['jquery'],
                    '1.0',
                    true
                );
                wp_localize_script('lpmanager-tracking', 'lpmanager_vars', [
                    'ajaxurl' => admin_url('admin-ajax.php'),
                    'nonce'   => wp_create_nonce('lpmanager_nonce'),
                ]);
            }
        }
    }


    public static function record_conversion() {
        check_ajax_referer('lpmanager_nonce', 'nonce');
        $post_id = absint($_POST['post_id']);
        $conversions = (int) get_post_meta($post_id, '_lpmanager_conversions', true);
        update_post_meta($post_id, '_lpmanager_conversions', $conversions + 1);
        wp_send_json_success('Conversion recorded.');
    }

    public static function render_conversions_page() {
        if (!carbon_get_theme_option('lpmanager_enable_conversion_tracking')) {
            echo '<div class="wrap"><h1>Conversions</h1><p>Conversion tracking is currently disabled. Enable it in settings to view analytics.</p></div>';
            return;
        }
        echo '<div class="wrap">';
        echo '<h1>Conversions</h1>';
        echo '<p>This table shows phone link click conversions for each landing page.</p>';
        echo '<table class="widefat fixed striped">';
        echo '<thead><tr><th>Landing Page</th><th>Visits</th><th>Conversions</th><th>Conversion Rate</th></tr></thead><tbody>';
        $pages = get_posts([
            'post_type' => 'landing_page',
            'posts_per_page' => -1
        ]);
        foreach ($pages as $page) {
            $visits = (int) get_post_meta($page->ID, '_lpmanager_page_views', true);
            $conversions = (int) get_post_meta($page->ID, '_lpmanager_conversions', true);
            $rate = $visits > 0 ? round(($conversions / $visits) * 100, 1) . '%' : '0%';
            $edit_link = get_edit_post_link($page->ID);
            echo '<tr>';
            echo '<td><a href="' . esc_url($edit_link) . '">' . esc_html(get_the_title($page)) . '</a></td>';
            echo '<td>' . esc_html($visits) . '</td>';
            echo '<td>' . esc_html($conversions) . '</td>';
            echo '<td>' . esc_html($rate) . '</td>';
            echo '</tr>';
        }
        echo '</tbody></table>';
        echo '</div>';
    }
	
	public static function maybe_add_conversions_submenu() {
        if (function_exists('carbon_get_theme_option') && carbon_get_theme_option('lpmanager_enable_conversion_tracking')) {
            add_submenu_page(
                'lp_dashboard',
                'Conversions',
                'Conversions',
                'manage_options',
                'lp_conversions',
                [__CLASS__, 'render_conversions_page']
            );
        }
    }
}
