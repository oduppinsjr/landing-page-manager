<?php
/**
 * Class Admin_Dashboard
 * 
 * Handles the 'client' taxonomy for Landing Pages,
 * including term meta, admin columns, and admin UI customizations.
 */
namespace LPManager\admin;

class Admin_Dashboard {

    public static function init() {
        add_action( 'admin_menu', [ __CLASS__, 'register_menu_page' ] );
        
		// Add dashboard widget on WP Dashboard screen
        add_action('wp_dashboard_setup', [ __CLASS__, 'add_dashboard_widgets' ]);

        // Add submenu for plugin dashboard
        add_action( 'admin_menu', [ __CLASS__, 'register_dashboard_page' ] );
        add_action( 'admin_menu', [ __CLASS__, 'add_dashboard_submenu' ] );
        
        add_action('admin_enqueue_scripts', [__CLASS__, 'enqueue_admin_assets']);
    }
	
    public static function enqueue_assets() {
        wp_enqueue_script(
            'lpmanager-dashboard',
            plugin_dir_url(__FILE__) . '../assets/js/dashboard.js',
            ['chart-js-handle'], // make sure Chart.js is a dependency
            '1.0.0',
            true
        );

        // Pass the REST API URL to the JS script
        wp_localize_script('lpmanager-dashboard', 'lpmanagerDashboard', [
            'apiUrl' => rest_url('lpmanager/v1/dashboard-data'),
            'nonce'  => wp_create_nonce('wp_rest'),
        ]);
    }
    
    public static function enqueue_admin_assets($hook) {
    	if (strpos($hook, 'lp_dashboard') === false) {
            return;
        }

        // Load Chart.js from CDN
        wp_enqueue_script(
            'chartjs',
            'https://cdn.jsdelivr.net/npm/chart.js',
            [],
            '4.4.1',
            true
        );

        // Load your dashboard JS, with Chart.js as a dependency
        wp_enqueue_script(
            'lp-dashboard-js',
            LP_MANAGER_PLUGIN_URL . 'assets/js/dashboard.js',
            ['chartjs'],
            '1.0.0',
            true
        );

        // Localize the REST API URL and Nonce
        wp_localize_script(
            'lp-dashboard-js',
            'lpmanagerDashboard',
            [
                'apiUrl' => rest_url('lpmanager/v1/dashboard-data'),
                'nonce'  => wp_create_nonce('wp_rest')
            ]
        );

        // Optional: Load dashboard CSS
        wp_enqueue_style(
            'lp-dashboard-css',
            LP_MANAGER_PLUGIN_URL . 'assets/css/dashboard.css',
            [],
            '1.0.0'
        );
    }
    
    public static function get_dashboard_data( $request ) {
        // Landing page counts
        $counts = wp_count_posts( 'landing_page' );
        $data['landing_pages'] = [
            'publish' => (int) $counts->publish,
            'draft'   => (int) $counts->draft,
            'pending' => (int) $counts->pending
        ];

        // Client taxonomy count (used outside charts)
        $clients_count = wp_count_terms( 'client', [ 'hide_empty' => false ] );
        $data['clients'] = is_wp_error( $clients_count ) ? 0 : (int) $clients_count;

        // Keywords taxonomy counts
        $terms = get_terms( [ 'taxonomy' => 'keyword', 'hide_empty' => false ] );
        $data['keywords'] = [];
        if ( is_wp_error( $terms ) ) {
            $terms = [];
        }
        foreach ( $terms as $term ) {
            $data['keywords'][] = [
                'label' => $term->name,
                'count' => $term->count
            ];
        }

        // Get all landing pages
        $pages = get_posts( [
            'post_type'      => 'landing_page',
            'posts_per_page' => -1
        ] );

        // Visits per page (post meta)
        $visits_per_page = [];
        $conversions_per_page = [];
        foreach ( $pages as $page ) {
            $visits = (int) get_post_meta( $page->ID, '_lpmanager_page_views', true );
            $conversions = (int) get_post_meta( $page->ID, '_lpmanager_conversions', true );
            $visits_per_page[ $page->post_title ] = $visits;
            $conversions_per_page[ $page->post_title ] = $conversions;
        }
        $data['visits_per_page'] = $visits_per_page;
        $data['conversions_per_page'] = $conversions_per_page;

        // Total keyword count (optional)
        $data['keyword_count'] = count( $terms );

        // Daily visits (option, fallback to empty array)
        $daily_visits = get_option( 'lpmanager_daily_visits', [] );
        $data['daily_visits'] = $daily_visits ?: [];

        // Daily conversions (option, fallback to empty array)
        $daily_conversions = get_option( 'lpmanager_daily_conversions', [] );
        $data['daily_conversions'] = $daily_conversions ?: [];

        return new \WP_REST_Response( $data, 200 );
    }

    public static function register_menu_page() {
        add_menu_page(
            'Landing Pages',
            'Landing Pages',
            'manage_options',
    		'lp_dashboard',
            '',  // No callback, CPT listing handles output
            'dashicons-media-document',
    		21
        );
		
        // Submenu: Dashboard (required for top-level menu to show submenu)
        add_submenu_page(
            'lp_dashboard',
            'Dashboard',
            'Dashboard',
            'manage_options',
            'lp_dashboard',
            [ __CLASS__, 'render_dashboard_page' ]
        );
        
        // Submenu: Landing Pages CPT listing
        add_submenu_page(
            'lp_dashboard',
            'Landing Pages',
            'Landing Pages',
            'edit_posts',
            'edit.php?post_type=landing_page'
        );

        // Submenu: Clients taxonomy
        add_submenu_page(
            'lp_dashboard',
            'Clients',
            'Clients',
            'manage_options',
            'edit-tags.php?taxonomy=client&post_type=landing_page'
        );
        
        // Submenu: Keyword taxonomy
        add_submenu_page(
            'lp_dashboard',
            'Keywords',
            'Keywords',
            'manage_options',
            'edit-tags.php?taxonomy=keyword&post_type=landing_page'
        );
        
    }
	
    public static function add_dashboard_widgets() {
        wp_add_dashboard_widget(
            'lp_dashboard_widget',
            __( 'Landing Page Manager Overview', 'landing-page-manager' ),
            [ __CLASS__, 'render_dashboard_widget' ]
        );
    }

    public static function render_dashboard_widget() {
        $counts = wp_count_posts( 'landing_page' );
        $total  = (int) ( $counts->publish ?? 0 ) + (int) ( $counts->draft ?? 0 ) + (int) ( $counts->pending ?? 0 );
        $clients = wp_count_terms( 'client', [ 'hide_empty' => false ] );
        $clients = is_wp_error( $clients ) ? 0 : (int) $clients;
        $dashboard_url = admin_url( 'admin.php?page=lp_dashboard' );
        ?>
        <p><?php echo esc_html( sprintf( __( 'You have %d landing pages and %d clients.', 'landing-page-manager' ), $total, $clients ) ); ?></p>
        <p>
            <a href="<?php echo esc_url( $dashboard_url ); ?>" class="button button-primary"><?php esc_html_e( 'Open Dashboard', 'landing-page-manager' ); ?></a>
            <a href="<?php echo esc_url( admin_url( 'post-new.php?post_type=landing_page' ) ); ?>" class="button"><?php esc_html_e( 'Add Landing Page', 'landing-page-manager' ); ?></a>
        </p>
        <?php
    }
    
    public static function register_dashboard_page() {
        // Redundant: Dashboard is already added as first submenu under lp_dashboard in register_menu_page().
        // This hook is kept for backwards compatibility but targets non-existent parent; safe to no-op or remove.
    }
    
    public static function render_settings_page() {
	    echo '<div class="wrap">';
	    echo '<h1>' . esc_html__( 'Landing Page Manager Settings', 'landing-page-manager' ) . '</h1>';
	    echo '<p>Use the settings below to configure global plugin behavior.</p>';
	    do_action( 'carbon_fields_container_lp_dashboard' ); // optionally trigger a custom hook if needed
	    echo '</div>';

    }
    
    public static function add_dashboard_submenu() {
        add_submenu_page(
            'edit.php?post_type=landing_page', // Parent slug (this attaches it to the Landing Pages menu)
            __( 'Dashboard', 'landing-page-manager' ), // Page title
            __( 'Dashboard', 'landing-page-manager' ), // Menu label
            'manage_options', // Capability
            'lp_dashboard', // Menu slug
            [ __CLASS__, 'render_dashboard_page' ] // Callback function
        );
    }

    public static function render_dashboard_page() {
        $landing_pages_count = wp_count_posts( 'landing_page' );
        $clients_count       = wp_count_terms( 'client', [ 'hide_empty' => false ] );
        $total_landing_pages = (int) ( $landing_pages_count->publish ?? 0 ) + (int) ( $landing_pages_count->draft ?? 0 ) + (int) ( $landing_pages_count->pending ?? 0 );
        $clients_count       = is_wp_error( $clients_count ) ? 0 : (int) $clients_count;

        $recent_pages = get_posts( [
            'post_type'      => 'landing_page',
            'posts_per_page' => 5,
            'orderby'        => 'date',
            'order'          => 'DESC',
        ] );

        $chart_ids = [
            'landingPageChart',
            'visitsPerPageChart',
            'visitsPerKeywordChart',
            'dailyVisitsChart',
            'topConvertersChart',
            'keywordChart',
        ];
        ?>
        <div class="wrap lp-dashboard">
            <h1><?php esc_html_e( 'Landing Page Manager Dashboard', 'landing-page-manager' ); ?></h1>

            <div class="lp-dashboard__actions">
                <a href="<?php echo esc_url( admin_url( 'post-new.php?post_type=landing_page' ) ); ?>" class="button button-primary"><?php esc_html_e( 'Add New Landing Page', 'landing-page-manager' ); ?></a>
                <a href="<?php echo esc_url( admin_url( 'edit-tags.php?taxonomy=client&post_type=landing_page' ) ); ?>" class="button"><?php esc_html_e( 'Manage Clients', 'landing-page-manager' ); ?></a>
                <a href="<?php echo esc_url( admin_url( 'edit.php?post_type=landing_page' ) ); ?>" class="button"><?php esc_html_e( 'All Landing Pages', 'landing-page-manager' ); ?></a>
            </div>

            <div class="lp-stats">
                <div class="lp-stat-card">
                    <h3><?php esc_html_e( 'Total Landing Pages', 'landing-page-manager' ); ?></h3>
                    <p class="lp-stat-card__value"><?php echo esc_html( (string) $total_landing_pages ); ?></p>
                </div>
                <div class="lp-stat-card">
                    <h3><?php esc_html_e( 'Total Clients', 'landing-page-manager' ); ?></h3>
                    <p class="lp-stat-card__value"><?php echo esc_html( (string) $clients_count ); ?></p>
                </div>
            </div>

            <section class="lp-section">
                <h2><?php esc_html_e( 'Recent Landing Pages', 'landing-page-manager' ); ?></h2>
                <?php if ( empty( $recent_pages ) ) : ?>
                    <p><?php esc_html_e( 'No recent landing pages found.', 'landing-page-manager' ); ?></p>
                <?php else : ?>
                    <ul class="lp-recent-list">
                        <?php foreach ( $recent_pages as $page ) :
                            $edit_link = get_edit_post_link( $page->ID );
                            ?>
                            <li>
                                <a href="<?php echo esc_url( $edit_link ); ?>"><?php echo esc_html( get_the_title( $page ) ); ?></a>
                                <span class="lp-recent-list__status">(<?php echo esc_html( get_post_status( $page ) ); ?>)</span>
                            </li>
                        <?php endforeach; ?>
                    </ul>
                <?php endif; ?>
            </section>

            <section class="lp-section">
                <h2><?php esc_html_e( 'Landing Page Analytics', 'landing-page-manager' ); ?></h2>
                <div class="lp-charts">
                    <?php foreach ( $chart_ids as $id ) : ?>
                        <div class="lp-chart-card">
                            <canvas id="<?php echo esc_attr( $id ); ?>" width="400" height="300"></canvas>
                        </div>
                    <?php endforeach; ?>
                </div>
            </section>
        </div>
        <?php
    }

}
