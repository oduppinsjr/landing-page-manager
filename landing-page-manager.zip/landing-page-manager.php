<?php
/**
 * Plugin Name: Landing Page Manager (Internal)
 * Description: MVP plugin to manage multi-client landing pages with subdomain routing.
 * Version: 1.0.0
 * Author: Odell Duppins
 * Text Domain: landing-page-manager
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

if ( ! defined( 'LP_MANAGER_PLUGIN_URL' ) ) {
    define( 'LP_MANAGER_PLUGIN_URL', plugin_dir_url( __FILE__ ) );
}

if ( ! defined( 'LP_MANAGER_PLUGIN_PATH' ) ) {
    define( 'LP_MANAGER_PLUGIN_PATH', plugin_dir_path( __FILE__ ) );
}

// Load composer autoloader first (needed for LPManager namespace classes)
if ( ! file_exists( __DIR__ . '/vendor/autoload.php' ) ) {
    add_action( 'admin_notices', function () {
        echo '<div class="notice notice-error"><p>' . esc_html__( 'Landing Page Manager: Composer autoload missing. Run composer install.', 'landing-page-manager' ) . '</p></div>';
    } );
    return;
}
require_once __DIR__ . '/vendor/autoload.php';

add_action( 'after_setup_theme', function() {
    \Carbon_Fields\Carbon_Fields::boot();
});

use LPManager\Plugin;

// Initialize plugin
add_action( 'plugins_loaded', function() {
    Plugin::init();
});

// Register activation hook (must be outside class)
register_activation_hook( __FILE__, [ Plugin::class, 'activate' ] );

// Start output buffering early for REST API requests (avoids stray output in JSON)
add_action( 'rest_api_init', function () {
    ob_start();
}, 0 );

add_action( 'rest_api_init', function () {
    register_rest_route( 'lpmanager/v1', '/dashboard-data', [
        'methods'             => 'GET',
        'callback'            => [ LPManager\admin\Admin_Dashboard::class, 'get_dashboard_data' ],
        'permission_callback' => function () {
            return current_user_can( 'manage_options' );
        },
    ] );
    register_rest_route( 'lpmanager/v1', '/get-brand-colors', [
        'methods'             => 'POST',
        'callback'            => [ 'LPManager\taxonomy\Client_Taxonomy', 'handle_brandfetch_request' ],
        'permission_callback' => function () {
            return current_user_can( 'manage_options' );
        },
    ] );
}, 10 );

add_filter( 'rest_post_dispatch', function ( $response, $server, $request ) {
    if ( ob_get_length() ) {
        ob_end_clean();
    }
    return $response;
}, 100, 3 );

if ( ! function_exists( 'wp_doing_rest' ) ) {
    function wp_doing_rest() {
        // This is how WP core defines it
        if ( defined( 'REST_REQUEST' ) && REST_REQUEST ) {
            return true;
        }
        return false;
    }
}

add_action( 'template_redirect', function () {
    if ( is_singular( 'landing_page' ) &&
        ! is_admin() &&
        ! wp_doing_ajax() &&
        ! wp_doing_rest()
    ) {
            // Remove only known unwanted plugin scripts/styles
            add_action('wp_enqueue_scripts', function() {
                $unwanted_styles = apply_filters('lpmanager_unwanted_styles', [
                    'elementor-common',
                    'elementor-pro',
                    'elementor-frontend',
                    'elementor-post-3',
                    'elementor-post-2708',
                    'elementor-post-2702',
                    'elementor-post-2693',
                    'hello-elementor',
                    'hello-elementor-theme-style',
                    'hello-elementor-header-footer',
                    'elementor-icons',  // sometimes enqueued separately
                    'font-awesome',
                    'fontawesome',
                    // Add more as needed
                ]);
                foreach ($unwanted_styles as $style) {
                    wp_dequeue_style($style);
                }
    
                $unwanted_scripts = apply_filters('lpmanager_unwanted_scripts', [
                    'elementor-common',
                    'elementor-pro-notes',
                    'elementor-pro-notes-app-initiator',
                    'elementor-pro-app',
                    'elementor-app-loader',
                    'elementor-frontend',
                    // Add more as needed
                ]);
                foreach ($unwanted_scripts as $script) {
                    wp_dequeue_script($script);
                }
            }, 100);
    
            // Remove only specific actions
            remove_action('wp_head', 'googlesitekit_print_head_scripts', 20);
            remove_action( 'wp_footer', 'googlesitekit_print_footer_scripts', 20 );
        }
} );

// Custom action for your own tracking/scripts on landing pages
function lpmanager_custom_landing_page_footer() {
    /**
     * Place your AdWords or other tracking scripts here.
     */
    // You can also use a filter here for extensibility
    do_action('lpmanager_landing_page_footer');
}

add_action( 'admin_enqueue_scripts', function( $hook ) {
    if ( 'edit-tags.php' === $hook && isset( $_GET['taxonomy'] ) && 'client' === $_GET['taxonomy'] ) {
        wp_enqueue_script( 'client-brandfetch', plugin_dir_url( __FILE__ ) . 'assets/js/client-brandfetch.js', [ 'jquery' ], '1.0', true );
        wp_localize_script( 'client-brandfetch', 'lpmanager_ajax', [
            'rest_url' => rest_url( 'lpmanager/v1/get-brand-colors' ),
            'nonce'    => wp_create_nonce( 'wp_rest' ),
        ] );
    }
} );
